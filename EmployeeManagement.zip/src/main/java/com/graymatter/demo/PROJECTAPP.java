package com.graymatter.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PROJECTAPP {

	public static void main(String[] args) {
		SpringApplication.run(PROJECTAPP.class, args);
	}

}
